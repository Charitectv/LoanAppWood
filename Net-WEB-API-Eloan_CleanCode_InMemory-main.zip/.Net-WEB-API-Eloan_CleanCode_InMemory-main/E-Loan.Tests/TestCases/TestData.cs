﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E_Loan.Tests.TestCases
{
    public class TestData
    {
        public string companyId { get; set; }
        public string companyName { get; set; }
        public string output { get; set; }
        public string questionText { get; set; }
        public string testCaseName { get; set; }
        public string testCaseType { get; set; }
        public string testName { get; set; }
        public string user { get; set; }
        public int version { get; set; }
    }
}
